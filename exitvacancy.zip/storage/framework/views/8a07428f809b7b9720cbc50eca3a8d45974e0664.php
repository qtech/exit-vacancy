<?php $__env->startSection('content'); ?>
<div class="box-typical" style="padding-left:25px;">
    <h5 class="m-t-lg with-border">Send Mail</h5>
    <form>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Subject</label>
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
                    <small class="text-muted">Please give a subject to your Mail</small>
                </fieldset>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="message">Description</label>
                    <textarea rows="4" name="message" id="message" class="form-control" placeholder="Textarea"></textarea>
                </fieldset>
            </div>
        </div>
    </form>
</div>

<section class="card">
    <div class="card-block">
            <h3>Hotel Owners</h3>
        <br>
        <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th><input type="checkbox" id="select_all"></th>
                <th>Name</th>
                <th>Email</th>
                <th>Number</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Bookings</th>
                <th>User Status</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $hotelusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <input type="checkbox" class="checkbox" name="mails[]" value="<?php echo e($value->user_id); ?>">
                    </td>
                    <td><?php echo e($value->fname); ?> <?php echo e($value->lname); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->hotel->number); ?></td>
                    <td>
                        <?php if($value->is_email_verify == 1): ?>
                            <label class="label label-success">Verified</label>
                        <?php else: ?>
                            <label class="label label-danger">Not Verified</label>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($value->is_mobile_verify == 1): ?>
                            <label class="label label-success">Verified</label>
                        <?php else: ?>
                            <label class="label label-danger">Not Verified</label>
                        <?php endif; ?>
                    </td>
                    <td style="text-align:center;"><strong><?php echo e(count($value->hotelbookings)); ?></strong></td>
                    <td>
                        <?php if($value->user_status == 1): ?>
                            <a href="<?php echo e(route('disableuser',['id' => $value->user_id])); ?>"><label class="label label-success">Active</label></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('enableuser',['id' => $value->user_id])); ?>"><label class="label label-danger">In-Active</label></a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <br>
        <div class="form-group">
            <div class="col-lg-12">
                <input onclick="addmail(); event.preventDefault();" type="submit" class="btn btn-custom" value="Send Mail">
                <a href="<?php echo e(route('h.mails')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    function addmail(){
        var temp = [];
        var subject = document.getElementById("subject").value;
        var message = document.getElementById("message").value;
        var users = document.getElementsByClassName("checkbox");

        for(let i=0;i<users.length;i++)
        {
            var demo = document.getElementsByClassName("checkbox")[i].checked;
            if(demo)
            {
                temp.push(document.getElementsByClassName("checkbox")[i].value);
            }
        }

        var param = {
            "subject":subject,
            "message":message,
            "mails":temp,
            "_token":'<?php echo e(csrf_token()); ?>'
        }

        var ajx = new XMLHttpRequest();
        ajx.onreadystatechange = function () {
            if (ajx.readyState == 4 && ajx.status == 200) {
                var demo = JSON.parse(ajx.responseText);
                if(demo.status == 1)
                {
                    notification('success',demo.msg);
                    setTimeout(function(){
                        window.location.href = '<?php echo e(route("h.mails")); ?>';
                    },1500);
                }
                else
                {
                    notification('danger',demo.msg);
                }
            }
        };
        ajx.open("POST", "<?php echo e(route('h.storemail')); ?>", true);
        ajx.setRequestHeader("Content-type", "application/json");
        ajx.send(JSON.stringify(param));
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('#select_all').on('click',function(){
            if(this.checked){
                $('.checkbox').each(function(){
                    this.checked = true;
                });
            }else{
                 $('.checkbox').each(function(){
                    this.checked = false;
                });
            }
        });
        
        $('.checkbox').on('click',function(){
            if($('.checkbox:checked').length == $('.checkbox').length){
                $('#select_all').prop('checked',true);
            }else{
                $('#select_all').prop('checked',false);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>