<?php $__env->startSection('content'); ?>
<div class="box-typical" style="padding-left:25px;">
    <h4 class="m-t-lg with-border">Hotel Profile</h4>
    <form id="myform" method="POST">
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Number</label>
                    <input type="text" class="form-control" name="number" id="number" value="<?php echo e($getdetails['details']->hotel->number); ?>">
                    <small class="text-muted">Update number for your Hotel</small>
                </fieldset>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Hotel Class</label>
                    <input type="number" class="form-control" name="hotelclass" id="hotelclass" value="<?php echo e($getdetails['details']->hotel->stars); ?>">
                    <small class="text-muted">Update class for your Hotel</small>
                </fieldset>
            </div>
        </div>
        <?php    
            $split = explode(",", $getdetails['details']->hotel->amenities);
        ?>
        <div class="form-group">
            <div class="col-md-12">
                <label class="form-label semibold" for="title">Select Amenities</label>
                <select class="select2" name="amenities[]" id="amenities" multiple="multiple">
                    <?php $__currentLoopData = $getdetails['amenities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                        <?php if(in_array($tmp->amenity_name, $split)): ?>
                            selected
                        <?php endif; ?>
                        value="<?php echo e($tmp->amenity_name); ?>"><?php echo e($tmp->amenity_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Amenities</label>
                    <?php $__currentLoopData = $split; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="label label-secondary"><?php echo e($value); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </fieldset>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Rooms Available</label>
                        <?php if($getdetails['details']->hotel->king_room > 0): ?>
                            <label class="label label-info"><?php echo e($getdetails['details']->hotel->king_room); ?> King Rooms</label>
                        <?php endif; ?> 
                        <?php if($getdetails['details']->hotel->queen_room > 0): ?>
                            <label class="label label-warning"><?php echo e($getdetails['details']->hotel->queen_room); ?> Two-Queen Rooms</label>
                        <?php endif; ?>
                </fieldset>
            </div>
        </div>
        <br>
        <div class="form-group">
            <div class="col-lg-12">
                <input onclick="editprofile(); event.preventDefault();" type="submit" class="btn btn-custom" value="Update">
            </div>
        </div>
    </form>
</div>

<script type="text/javascript">
    function editprofile(){
        var form = document.getElementById("myform");
        var formData = new FormData(form);
        formData.append('_token','<?php echo e(csrf_token()); ?>');
        

        var ajx = new XMLHttpRequest();
        ajx.onreadystatechange = function () {
            if (ajx.readyState == 4 && ajx.status == 200) {
                var demo = JSON.parse(ajx.responseText);
                if(demo.status == 1)
                {
                    notification('success',demo.msg);
                    setTimeout(function(){
                        window.location.href = '<?php echo e(route("hotelprofile")); ?>';
                    },1500);
                }
                else
                {
                    notification('danger',demo.msg);
                }
            }
        };
        ajx.open("POST", "<?php echo e(route('updatehotelprofile')); ?>", true);
        // ajx.setRequestHeader("Content-type", "application/json");
        ajx.send(formData);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>