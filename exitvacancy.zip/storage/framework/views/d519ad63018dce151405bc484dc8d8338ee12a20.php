<?php $__env->startSection('content'); ?>
<div class="box-typical" style="padding-left:25px;">
    <h4 class="m-t-lg with-border">Two Queens Room Details</h4>
    <?php    
        $split = explode(",", $room->queen_room_amenity);
    ?>
    <form id="myform" method="POST">
        <div class="form-group">
            <div class="col-md-12">
                <label class="form-label semibold" for="title">Select Amenities</label>
                <select class="select2" name="amenities[]" id="amenities" multiple="multiple">
                        <option
                        <?php if(in_array('Breakfast', $split)): ?>
                            selected
                        <?php endif; ?>
                        value="Breakfast">Breakfast</option>

                        <option
                        <?php if(in_array('Lunch', $split)): ?>
                            selected
                        <?php endif; ?>
                        value="Lunch">Lunch</option>

                        <option
                        <?php if(in_array('Dinner', $split)): ?>
                            selected
                        <?php endif; ?>
                        value="Dinner">Dinner</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Room Amenities</label>
                        <?php $__currentLoopData = $split; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="label label-info"><?php echo e($value); ?></label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </fieldset>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Price</label>
                    <input type="number" class="form-control" name="price" id="price" value="<?php echo e($room->queen_room_price); ?>">
                    <small class="text-muted">Update price of this room</small>
                </fieldset>
            </div>
        </div>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <label class="form-label semibold" for="title">Rooms Available</label>
                    <input type="number" class="form-control" name="rooms" id="rooms" value="<?php echo e($room->queen_room); ?>">
                    <small class="text-muted">Update number of rooms available</small>
                </fieldset>
            </div>
        </div>
        <br>
        <div class="form-group">
            <div class="col-lg-12">
                <fieldset class="form-group">
                    <a href="<?php echo e(route('s.addimages')); ?>" class="btn btn-custom pull-left">Add Images</a>
                    <input onclick="updateroom(); event.preventDefault();" type="submit" class="btn btn-custom pull-right" value="Update">
                </fieldset>
            </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript">
    function updateroom(){
        var form = document.getElementById("myform");
        var formData = new FormData(form);
        formData.append('_token','<?php echo e(csrf_token()); ?>');

        var ajx = new XMLHttpRequest();
        ajx.onreadystatechange = function () {
            if (ajx.readyState == 4 && ajx.status == 200) {
                var demo = JSON.parse(ajx.responseText);
                if(demo.status == 1)
                {
                    notification('success',demo.msg);
                    setTimeout(function(){
                        window.location.href = "<?php echo e(route('h.d.room')); ?>";   
                    },1000);
                }
                else
                {
                    notification('danger',demo.msg);
                }
            }
        };
        ajx.open("POST", "<?php echo e(route('h.d.update')); ?>", true);
        //ajx.setRequestHeader("Content-type", "application/json");
        ajx.send(formData);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>