;

<?php $__env->startSection('content'); ?>
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="page-content-wrapper">
            <div class="container">
                <div id="error" class="alert alert-danger alert-dismissible fade in" style="display:none">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                </div>
                <div id="success" class="alert alert-success alert-dismissible fade in" style="display:none">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="panel panel-primary" style="box-shadow:0px 0px 10px 4px #cccccc">
                            <div class="panel-body">
                                <h4 class="m-t-0 m-b-30">Super-Deluxe Room details</h4>
                                <form class="form-horizontal">
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Amenities</label>
                                        <div class="col-md-10">
                                        <input name="amenities" id="amenities" type="text" class="form-control" value="<?php echo e($room->superdeluxe_room_amenity); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Price</label>
                                        <div class="col-md-10">
                                            <input name="price" id="price" type="number" class="form-control" value="<?php echo e($room->superdeluxe_room_price); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Rooms Available</label>
                                        <div class="col-md-10">
                                            <input name="rooms" id="rooms" type="number" class="form-control" value="<?php echo e($room->superdeluxe_room); ?>">
                                        </div>
                                    </div>
                                    <br>
                                    <a href="<?php echo e(route('sd.addimages')); ?>" class="btn btn-warning">Add Images</a>
                                    <input onclick="addnotification(); event.preventDefault();" type="submit" class="btn btn-primary pull-right" value="Update">
                                </form>      
                            </div> <!-- panel-body -->
                        </div> <!-- panel -->
                    </div> <!-- col -->
                </div> <!-- End row -->
            </div><!-- container -->
        </div> <!-- Page content Wrapper -->
    </div> <!-- content -->
</div>

<script type="text/javascript">
    function addnotification(){
        var amenity = document.getElementById("amenities").value;
        var price = document.getElementById("price").value;
        var number = document.getElementById("rooms").value;
        var param = {
            "amenity":amenity,
            "price":price,
            "rooms":number,
            "_token":'<?php echo e(csrf_token()); ?>'
        }

        var ajx = new XMLHttpRequest();
        ajx.onreadystatechange = function () {
            if (ajx.readyState == 4 && ajx.status == 200) {
                var demo = JSON.parse(ajx.responseText);
                if(demo.status == 1)
                {
                    document.getElementById('success').style.display = "block";
                    document.getElementById('success').innerHTML = "<strong>"+demo.msg+"</strong>";
                    setTimeout(function(){
                        window.location.href = "<?php echo e(route('h.sd.room')); ?>";   
                    },1000);
                }
                else
                {
                    document.getElementById('error').style.display = "block";
                    document.getElementById('error').innerHTML = "<strong>"+demo.msg+"</strong>";
                    setTimeout(function(){
                        window.location.href = "<?php echo e(route('h.sd.room')); ?>";
                    },1000);
                }
            }
        };
        ajx.open("PUT", "<?php echo e(route('h.sd.update')); ?>", true);
        ajx.setRequestHeader("Content-type", "application/json");
        ajx.send(JSON.stringify(param));
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>