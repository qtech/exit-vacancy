<?php $__env->startSection('content'); ?>
<header class="section-header">
    <div class="tbl">
        <div class="tbl-row">
            <div class="tbl-cell">
                <h3 class="pull-left">User Bookings</h3>
                <a href="<?php echo e(route('appusers')); ?>" class="btn btn-custom pull-right">Back</a>
            </div>
        </div>
    </div>
</header>
<section class="card">
    <div class="card-block">
        <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Hotel Name</th>
                    <th>Room Type</th>
                    <th>Room Price</th>
                    <th>Status</th>
                    <th>Room Image</th>
                    <th>Arrival</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $userbookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  
                    $hotel = App\Hoteldata::where(['hotel_data_id' => $value->hotel_id])->first();  
                ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($hotel->hotel_name); ?></td>
                    <td><?php echo e($value->roomtype); ?></td>
                    <td>$<?php echo e($value->roomprice); ?></td>
                    <td>
                        <?php if($value->status == 1): ?>
                            <label class="label label-success">Accepted</label>
                        <?php else: ?>
                            <label class="label label-danger">Declined</label>
                        <?php endif; ?>
                    </td>
                    <td>
                        <img height="30px;" width="60px;" src="<?php echo e(asset(url('/').'/'.$value->roomimage)); ?>">    
                    </td>
                    <td>
                        <?php if($value->is_visited == 1): ?>
                            <label class="label label-success">Visited</label>
                        <?php else: ?>
                            <label class="label label-danger">Not Visited</label>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>