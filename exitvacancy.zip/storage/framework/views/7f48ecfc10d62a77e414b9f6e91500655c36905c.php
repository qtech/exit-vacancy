<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xxl-12 col-lg-12 col-xl-12 col-md-12">
        <section class="box-typical proj-page">
            <section class="proj-page-section proj-page-header">
                <div class="tbl proj-page-team">
                    <div class="tbl-row">
                        <div class="tbl-cell tbl-cell-admin">
                            <div class="avatar-preview avatar-preview-32">
                                <a href="#">
                                    <img src="<?php echo e(asset('user.png')); ?>" alt="">
                                </a>
                            </div>
                            <div class="title">
                                &nbsp;<?php echo e($user->fname); ?> <?php echo e($user->lname); ?>

                            </div>
                        </div>
                        <div class="tbl-cell tbl-cell-date">
                            <strong>Last Login:</strong> <?php echo e($user->last_login); ?>

                            <a href="<?php echo e(route('appusers')); ?>" class="btn btn-sm btn-custom" style="margin-left:25px;">BACK</a>
                        </div>
                    </div>
                </div>
            </section><!--.proj-page-section-->

            <section class="proj-page-section proj-page-people">
                    <header class="proj-page-subtitle padding-sm">
                        <h3>Details</h3>
                    </header>
                    <br>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="tbl tbl-people">
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">Joined</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e(date('d-M-Y', strtotime($user->created_at))); ?></div>
                                </div>
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">Email</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e($user->email); ?></div>
                                </div>
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">Number</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e($user->customer->number); ?></div>
                                </div>
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">Address</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e($user->customer->building); ?>, <?php echo e($user->customer->street); ?></div>
                                </div>
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">City</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e($user->customer->city); ?></div>
                                </div>
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">State</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e($user->customer->state); ?></div>
                                </div>
                                <div class="tbl-row">
                                    <div class="tbl-cell tbl-cell-lbl">Country</div>
                                    <div class="tbl-cell" style="font-size:14px;"><?php echo e($user->customer->country); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6" style="margin-top:-15px;">
                            <div id="userwrapper">
                                <canvas id="userChart" width="400" height="100"></canvas>
                            </div>
                        </div>
                    </div>
                </section>

            <section class="proj-page-section proj-page-people">
                <header class="proj-page-subtitle padding-sm">
                    <h3>Bookings</h3>
                </header>
                <br>
                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Hotel Name</th>
                        <th>Hotel Class</th>
                        <th>Room Type</th>
                        <th>Price</th>
                        <th>Booking Time</th>
                        <th>Arrived</th>
                        <th>Arrived Time</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($value->hotel->hotel_name); ?></td>
                            <td style="text-align:center;">
                                <strong><?php echo e($value->hotel->stars); ?></strong> 
                                    <i class="font-icon font-icon-star" style="color:orange;"></i>
                            </td>
                            <td><?php echo e($value->roomtype); ?></td>
                            <td>$<?php echo e($value->roomprice); ?></td>
                            <td><?php echo e(isset($value->status_time) ? $value->status_time : 'Not available'); ?></td>
                            <td style="text-align:center;">
                                <?php if($value->is_visited == 1): ?>
                                    <label class="label label-success">YES</label>
                                <?php else: ?>
                                    <label class="label label-danger">NO</label>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(isset($value->visited_time) ? $value->visited_time : 'Not available'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section><!--.proj-page-section-->
        </section><!--.proj-page-->
    </div>
</div><!--.row-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            userbookings();
            Chart.defaults.global.defaultFontColor = 'grey';
            Chart.defaults.global.defaultFontStyle = 'bold';
            Chart.defaults.global.defaultFontSize = 11;
        });

        function userbookings(){
            
            var param = {
                "id":'<?php echo e($user->user_id); ?>',
                "_token":'<?php echo e(csrf_token()); ?>'
            }
            var ajx = new XMLHttpRequest();
            ajx.onreadystatechange = function () {
                if (ajx.readyState == 4 && ajx.status == 200) {
                        var res = JSON.parse(ajx.responseText);                                        
                        var data = {
                            labels: res.dateLabel,
                            datasets:[{
                                label:'Completed',
                                fill: false, 
                                tension: 0.4,                           
                                backgroundColor: "#00857B",
                                borderColor: "#00857B", // The main line color
                                borderCapStyle: 'square',
                                borderDash: [], // try [5, 15] for instance
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "black",
                                pointBackgroundColor: "white",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "red",
                                pointHoverBorderColor: "brown",
                                pointHoverBorderWidth: 2,
                                pointRadius: 4,
                                pointHitRadius: 10,
                                data:res.completed,
                                spanGaps: true,
                            },{
                                label:'Pending', 
                                fill: false, 
                                tension: 0.4,                           
                                backgroundColor: "rgb(167, 105, 0)",
                                borderColor: "rgb(167, 105, 0)",
                                borderCapStyle: 'butt',
                                borderDash: [],
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "white",
                                pointBackgroundColor: "black",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "yellow",
                                pointHoverBorderColor: "green",
                                pointHoverBorderWidth: 2,
                                pointRadius: 4,
                                pointHitRadius: 10,
                                data:res.pending,
                                spanGaps: false,                          
                            },{
                                label:'Cancelled', 
                                fill: false, 
                                tension: 0.4,                           
                                backgroundColor: "red",
                                borderColor: "red",
                                borderCapStyle: 'butt',
                                borderDash: [],
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "white",
                                pointBackgroundColor: "black",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "black",
                                pointHoverBorderColor: "brown",
                                pointHoverBorderWidth: 2,
                                pointRadius: 4,
                                pointHitRadius: 10,
                                data:res.cancelled,
                                spanGaps: false,                          
                            }],
                        }

                        $('#userChart').remove();
                        $('#userwrapper').append('<canvas id="userChart" width="400" height="200"></canvas>');
                        //Start Chart plotting.
                        var ctx = $('#userChart');
                        var myLineChart = new Chart(ctx, {
                            type:'line',
                            data:data
                        });
                }
            };
            ajx.open("POST", "<?php echo e(route('u.bookingchart')); ?>", true);
            ajx.setRequestHeader("Content-type", "application/json");
            ajx.send(JSON.stringify(param));
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>