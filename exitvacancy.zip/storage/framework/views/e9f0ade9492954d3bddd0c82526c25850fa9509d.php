<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Welcome to <?php echo e(config('app.name')); ?></title>
    </head>
    <body paddingwidth="0" paddingheight="0" style="padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;" offset="0" toppadding="0" leftpadding="0" style="margin-left:5px; margin-right:5px; margin-top:0px; margin-bottom:0px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tableContent bgBody" align="center" style='font-family:helvetica, sans-serif;'>
<!--  =========================== The header ===========================  -->
<tbody>
<tr>
<td height='25' bgcolor='#43474A' colspan='3'></td>
</tr>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td valign="top" class="spechide">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td height='130' bgcolor='#43474A'>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td valign="top" width="600">
<table width="600" border="0" cellspacing="0" cellpadding="0" align="center" class="MainContainer" bgcolor="#ffffff">
<tbody>
<!--  =========================== The body ===========================  -->
<tr>
<td class='movableContentContainer'>
<div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
<tr>
<td bgcolor='#43474A' valign='top'>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
    <tr>
        <td align='left' valign='middle'>
            <div class="contentEditableContainer contentImageEditable">
                <div class="contentEditable">
                    <!-- <img src="<?php echo e(asset('logo.png')); ?>" alt='Company logo' data-default="placeholder" width="225px"> -->
                </div>
            </div>
        </td>
    </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
<tr>
<td align='left' valign='middle'>
<div class="contentEditableContainer contentImageEditable">
<div class="contentEditable">

</div>
</div>
</td>
</tr>
</table>
</td>
</tr>
</table>
</div>
<div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
<tr>
<td height='25' bgcolor='#43474A'></td>
</tr>
<tr>
<td height='5' bgcolor='#FFFFFF'></td>
</tr>
</table>
</div>
<div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
<tr>
<td>
<div class='contentEditableContainer contentImageEditable'>
<div class="contentEditable">
</div>
</div>
</td>
</tr>
<tr>
<td height='10' bgcolor='#000000'></td>
</tr>
<tr>
<td bgcolor='#000000' style='padding:8px 0;'>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="20" class="spechide">&nbsp;</td>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td align='left' valign='top' width='370' class="specbundle3">
<div class='contentEditableContainer contentTextEditable'>
<div class="contentEditable" style='font-size:21px;line-height:19px;'>
<p><span style="color:#ffffff;" class="font">Welcome to <?php echo e(config('app.name')); ?>, <?php echo e($data['fname']); ?> <?php echo e($data['lname']); ?></p>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</td>
<td width="20" class="spechide">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td height='10' bgcolor='#000000'></td>
</tr>
</table>
</div>
<div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;background-color: #f2f2f2;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
        <tr>
            <td width='291' class="specbundle2" valign='top'>
                <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
                    <tr>
                        <td height='15' colspan='3'></td>
                    </tr>
                    <tr>
                        <td width='20'></td>
                        <td>
                            <table border="0" cellspacing="0" cellpadding="0" align="center" valign='top'>
                                <tr>
                                    <td>
                                    	<br>
                                        <div class='contentEditableContainer contentTextEditable'>
                                            <div class='contentEditable' style='color:#cccccc;font-size:21px;font-weight:normal'>
                                                <h3>Your new password for ExitVacancy app is: </h3><h2 class='big'><?php echo e($data['password']); ?></h2>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td height='16'></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class='contentEditableContainer contentTextEditable'>
                                            <div class='contentEditable' style='color:#cccccc;font-size:13px;line-height:19px;'>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td height='16'></td>
                                </tr>
                            </table>
                        </td>
                        <td width='20'></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>
<div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign='top' class='bgBody' >
        <tr></tr>
        <tr>
            <td height='54' style='border-bottom:1px solid #DAE0E4; font-size: 10px;background-color: #43474A; color: white; text-align: center; padding: 0px 0px 0px 10px'>Copyright 2018 ExitVacancy. All rights reserved. </td>
        </tr>
    </table>
</div>
</td>
</tr>
</tbody>
</table>
</td>
<td valign="top" class="spechide">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tbody>
        <tr>
            <td height='130' bgcolor='#43474A'>&nbsp;</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
    </tbody>
</table>
</td>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body>
</html>

