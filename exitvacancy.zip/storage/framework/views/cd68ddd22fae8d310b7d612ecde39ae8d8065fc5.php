<?php $__env->startSection('content'); ?>
<header class="section-header">
    <div class="tbl">
        <div class="tbl-row">
            <div class="tbl-cell">
                <h3 class="pull-left">Hotel Details</h3>
                <a href="<?php echo e(route('hotelusers')); ?>" class="btn btn-custom pull-right">Back</a>
            </div>
        </div>
    </div>
</header>
<section class="card">
    <div class="card-block">
        <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Star</th>
                    <th>Base Price</th>
                    <th>Ratings</th>
                    <th>Image</th>
                    <th>Amenities</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($value->hotel_name); ?></td>
                    <td><?php echo e($value->stars); ?> <span class="font-icon font-icon-star" style="color:orange;"></span></td>
                    <td>$<?php echo e($value->price); ?></td>
                    <td><?php echo e($value->ratings); ?></td>
                    <td>
                        <img height="30px;" width="60px;" src="<?php echo e($value->image); ?>">    
                    </td>
                    <td>
                        <label class="label label-info"><?php echo e($value->amenities); ?></label>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>