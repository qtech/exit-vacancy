<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>ExitVacancy</title>

	<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.png" rel="icon" type="image/png">
	<link href="img/favicon.ico" rel="shortcut icon">

    <link rel="stylesheet" href="<?php echo e(asset('/n-asset/css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/n-asset/css/lib/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/n-asset/css/main.css')); ?>">
</head>
<body class="with-side-menu">

	<?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><!--.site-header-->

	<?php echo $__env->make('include.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><!--.side-menu-->

	<div class="page-content">
		<div class="container-fluid">
			<?php echo $__env->yieldContent('content'); ?>
		</div><!--.container-fluid-->
	</div><!--.page-content-->

	<script src="<?php echo e(asset('/n-asset/js/lib/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/n-asset/js/lib/popper/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/n-asset/js/lib/tether/tether.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/n-asset/js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/n-asset/js/plugins.js')); ?>"></script>
    
<script src="<?php echo e(asset('/n-asset/js/app.js')); ?>"></script>
</body>
</html>