<?php $__env->startSection('content'); ?>
<header class="section-header">
    <div class="tbl">
        <div class="tbl-row">
            <div class="tbl-cell">
                <h3 class="pull-left">User SMS</h3>
                <a href="<?php echo e(route('addsms')); ?>" class="btn btn-custom pull-right">Send SMS</a>
            </div>
        </div>
    </div>
</header>
<section class="card">
    <div class="card-block">
        <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Time</th>
                <th>Message</th>
                <th>Recipients</th>
            </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($value->created_at->format('d-m-y')); ?></td>
                    <td><?php echo e($value->created_at->format('H:i')); ?></td>
                    <td><?php echo e($value->message); ?></td>
                    <td>
                        <button type="button" class="btn btn-sm btn-custom" data-toggle="modal" data-target="#myModal<?php echo e($value->notification_id); ?>">View <i class="font-icon font-icon-eye"></i></button>
                    
                        <div class="modal fade" id="myModal<?php echo e($value->notification_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="myModalLabel">Recipients</h4>
                                    </div>
                                    <div class="modal-body">
                                        <table class="display table table-striped table-bordered recipients" cellspacing="0" width="100%">
                                            <thead>
                                                <th>Name</th>
                                                <th>Email</th>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $users = explode(',',$value->recipients);
                                                ?>
                                                <?php if(!empty($users)): ?>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $user = App\User::with('customer')->where(['user_id' => $tmp])->first();
                                                        ?>
                                                        <tr>
                                                            <td><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></td>
                                                            <td><?php echo e($user->customer->number); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div><!--.modal-->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<script>
    $(function() {
        $('.recipients').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>