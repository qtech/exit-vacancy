<?php $__env->startSection('content'); ?>

    
<header class="section-header">
    <div class="tbl">
        <div class="tbl-row">
            <div class="tbl-cell">
                <h3 class="pull-left">User Bookings</h3>
            </div>
        </div>
    </div>
</header>
<section class="card">
    <div class="card-block">
        <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Number</th>
                <th>Location</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
                <?php
                    $i = 1;
                ?>
                <?php $__currentLoopData = $getdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($value->user->fname); ?> <?php echo e($value->user->lname); ?></td>
                    <td><?php echo e($value->user->email); ?></td>
                    <td><?php echo e($value->customer->number); ?></td>
                    <td><?php echo e($value->customer->state); ?>, <?php echo e($value->customer->city); ?></td>
                    <td>
                        <?php if($value->status == 0): ?>
                        <label class="label label-secondary">Pending</label>
                        <?php endif; ?>
                        <?php if($value->status == 1): ?>
                        <label class="label label-success">Accepted</label>
                        <?php endif; ?>
                        <?php if($value->status == 2): ?>
                        <label class="label label-danger">Declined</label>
                        <?php endif; ?>
                        <?php if($value->status == 3): ?>
                        <label class="label label-warning">No response</label>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>