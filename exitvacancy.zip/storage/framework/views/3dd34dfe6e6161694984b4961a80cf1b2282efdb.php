<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xxl-12 col-lg-12 col-xl-12 col-md-12">
        <section class="box-typical proj-page">
            <section class="proj-page-section proj-page-header">
                <div class="tbl proj-page-team">
                    <div class="tbl-row">
                        <div class="tbl-cell tbl-cell-admin">
                            <div class="avatar-preview avatar-preview-32">
                                <a href="#">
                                    <img src="<?php echo e(asset('user.png')); ?>" alt="">
                                </a>
                            </div>
                            <div class="title">
                                <?php echo e($hoteluser->hotel->hotel_name); ?>

                            </div>
                        </div>
                        <div class="tbl-cell tbl-cell-date">
                            <strong>Last Login:</strong> <?php echo e($hoteluser->last_login); ?>

                            <a href="<?php echo e(route('hotelusers')); ?>" class="btn btn-sm btn-custom" style="margin-left:25px;">BACK</a>
                        </div>
                    </div>
                </div>
            </section><!--.proj-page-section-->

            <section class="proj-page-section proj-page-people">
                <header class="proj-page-subtitle padding-sm">
                    <h3>Details</h3>
                </header>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        <div class="tbl tbl-people">
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Joined</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e(date('d-M-Y', strtotime($hoteluser->created_at))); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Owner</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->fname); ?> <?php echo e($hoteluser->lname); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Class</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->stars); ?>

                                        <i class="font-icon font-icon-star" style="color:orange;"></i>
                                </div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Email</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->email); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Number</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->number); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Ratings</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->ratings); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Bookings</div>
                                <div class="tbl-cell" style="font-size:14px;"><strong><?php echo e($hoteluser->bookings); ?></strong></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Amenities</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->amenities); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Address</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->building); ?>, <?php echo e($hoteluser->hotel->street); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">City</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->city); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">State</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->state); ?></div>
                            </div>
                            <div class="tbl-row">
                                <div class="tbl-cell tbl-cell-lbl">Country</div>
                                <div class="tbl-cell" style="font-size:14px;"><?php echo e($hoteluser->hotel->country); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div id="hotelwrapper">
                            <canvas id="hotelChart" width="400" height="100"></canvas>
                        </div>
                    </div>
                </div>
            </section>

            <section class="proj-page-section proj-page-people">
                <header class="proj-page-subtitle padding-sm">
                    <h3>Images</h3>
                </header>
                <br>
                <div class="row">
                    <div class="col-sm-3">
                        <img src="<?php echo e($hoteluser->hotel->image); ?>">
                    </div>
                </div>  
            </section>

            <section class="proj-page-section proj-page-people">
                <header class="proj-page-subtitle padding-sm">
                    <h3>Bookings</h3>
                </header>
                <br>
                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Room Type</th>
                        <th>Room Price</th>
                        <th>Status</th>
                        <th>Arrived</th>
                        <th>Arrival Time</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($value->user->fname); ?> <?php echo e($value->user->lname); ?></td>
                            <td><?php echo e($value->roomtype); ?></td>
                            <td>$<?php echo e($value->roomprice); ?></td>
                            <td style="text-align:center;">
                                <?php if($value->status == 1): ?>
                                    <label class="label label-success">Accepted</label>
                                <?php else: ?>
                                    <label class="label label-danger">Declined</label>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <?php if($value->is_visited == 1): ?>
                                    <label class="label label-success">YES</label>
                                <?php else: ?>
                                    <label class="label label-danger">NO</label>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(isset($value->visited_time) ? $value->visited_time : 'Not available'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section><!--.proj-page-section-->
        </section><!--.proj-page-->
    </div>
</div><!--.row-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            hotelbookings();
            Chart.defaults.global.defaultFontColor = 'grey';
            Chart.defaults.global.defaultFontStyle = 'bold';
            Chart.defaults.global.defaultFontSize = 13;
        });

        function hotelbookings(){
            
            var param = {
                "id":'<?php echo e($hoteluser->user_id); ?>',
                "_token":'<?php echo e(csrf_token()); ?>'
            }
            var ajx = new XMLHttpRequest();
            ajx.onreadystatechange = function () {
                if (ajx.readyState == 4 && ajx.status == 200) {
                        var res = JSON.parse(ajx.responseText);                                        
                        var data = {
                            labels: res.dateLabel,
                            datasets:[{
                                label:'Completed',
                                fill: false, 
                                tension: 0.4,                           
                                backgroundColor: "#00857B",
                                borderColor: "#00857B", // The main line color
                                borderCapStyle: 'square',
                                borderDash: [], // try [5, 15] for instance
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "black",
                                pointBackgroundColor: "white",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "red",
                                pointHoverBorderColor: "brown",
                                pointHoverBorderWidth: 2,
                                pointRadius: 4,
                                pointHitRadius: 10,
                                data:res.completed,
                                spanGaps: true,
                            },{
                                label:'Pending', 
                                fill: false, 
                                tension: 0.4,                           
                                backgroundColor: "rgb(167, 105, 0)",
                                borderColor: "rgb(167, 105, 0)",
                                borderCapStyle: 'butt',
                                borderDash: [],
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "white",
                                pointBackgroundColor: "black",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "yellow",
                                pointHoverBorderColor: "green",
                                pointHoverBorderWidth: 2,
                                pointRadius: 4,
                                pointHitRadius: 10,
                                data:res.pending,
                                spanGaps: false,                          
                            },{
                                label:'Cancelled', 
                                fill: false, 
                                tension: 0.4,                           
                                backgroundColor: "red",
                                borderColor: "red",
                                borderCapStyle: 'butt',
                                borderDash: [],
                                borderDashOffset: 0.0,
                                borderJoinStyle: 'miter',
                                pointBorderColor: "white",
                                pointBackgroundColor: "black",
                                pointBorderWidth: 1,
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "black",
                                pointHoverBorderColor: "brown",
                                pointHoverBorderWidth: 2,
                                pointRadius: 4,
                                pointHitRadius: 10,
                                data:res.cancelled,
                                spanGaps: false,                          
                            }],
                        }

                        $('#hotelChart').remove();
                        $('#hotelwrapper').append('<canvas id="hotelChart" width="400" height="200"></canvas>');
                        //Start Chart plotting.
                        var ctx = $('#hotelChart');
                        var myLineChart = new Chart(ctx, {
                            type:'line',
                            data:data
                        });
                }
            };
            ajx.open("POST", "<?php echo e(route('h.bookingchart')); ?>", true);
            ajx.setRequestHeader("Content-type", "application/json");
            ajx.send(JSON.stringify(param));
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>