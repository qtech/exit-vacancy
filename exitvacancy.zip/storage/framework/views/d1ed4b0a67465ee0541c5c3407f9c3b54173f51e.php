<?php if(session('error')): ?>
<script>
	$(document).ready(function(){
		$.notify({
			icon: 'font-icon font-icon-warning',
			title: '<strong>Error!</strong>',
			message: '<?php echo e(session('error')); ?>'
		}, {
			type: 'danger'
		});
	});
</script>
<?php endif; ?>

<?php if(session('success')): ?>
<script>
$(document).ready(function(){
	$.notify({
		icon: 'font-icon font-icon-check-circle',
		title: '<strong>Success!</strong>',
		message: '<?php echo e(session('success')); ?>'
	}, {
		type: 'success'
	});
});
</script>
<?php endif; ?>

<?php if(count($errors)>0): ?>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<script>
		$(document).ready(function(){
			$.notify({
				icon: 'font-icon font-icon-warning',
				title: '<strong>Error!</strong>',
				message: '<?php echo e($error); ?>'
			}, {
				type: 'danger'
			});
		});
	</script>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
