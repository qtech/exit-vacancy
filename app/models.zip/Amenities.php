<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Amenities extends Model
{
    public $table = "amenities";
    protected $primaryKey = "amenity_id";
}
